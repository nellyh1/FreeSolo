<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="cloud" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="cloud.png" width="64" height="64"/>
</tileset>
