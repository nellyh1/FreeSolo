<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="crack2" tilewidth="32" tileheight="32" tilecount="81" columns="9">
 <image source="crack2.png" width="288" height="288"/>
</tileset>
