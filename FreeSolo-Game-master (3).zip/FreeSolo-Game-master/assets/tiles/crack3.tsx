<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="crack3" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="crack3.png" width="384" height="384"/>
</tileset>
