<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="rockobstacle" tilewidth="32" tileheight="32" tilecount="36" columns="6">
 <image source="rockobstacle.png" width="192" height="192"/>
</tileset>
