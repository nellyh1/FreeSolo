<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="sky" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <grid orientation="orthogonal" width="64" height="128"/>
 <image source="sky.png" width="32" height="32"/>
</tileset>
