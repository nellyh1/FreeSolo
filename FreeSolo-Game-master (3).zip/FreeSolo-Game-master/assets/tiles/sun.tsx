<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="sun" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="sun.png" width="96" height="96"/>
</tileset>
